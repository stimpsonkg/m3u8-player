package com.tvworld.player

data class ChannelItem(val name: String, val group: String, val url: String)
