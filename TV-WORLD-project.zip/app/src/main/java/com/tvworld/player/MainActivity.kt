package com.tvworld.player

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.tvworld.player.databinding.ActivityMainBinding
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var player: ExoPlayer
    private val channels = mutableListOf<ChannelItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        parsePlaylist()

        val adapter = ChannelAdapter(channels) { channel ->
            playUrl(channel.url)
        }
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        player = ExoPlayer.Builder(this).build()
        binding.playerView.player = player
    }

    private fun playUrl(url: String) {
        player.setMediaItem(MediaItem.fromUri(Uri.parse(url)))
        player.prepare()
        player.play()
    }

    private fun parsePlaylist() {
        val input = assets.open("playlist.m3u8")
        val reader = BufferedReader(InputStreamReader(input))
        var line: String?
        var lastInf: String? = null
        while (true) {
            line = reader.readLine() ?: break
            if (line.startsWith("#EXTINF")) {
                lastInf = line
            } else if (line.trim().isNotEmpty() && !line.startsWith("#")) {
                val url = line.trim()
                val name = extractAttr(lastInf, "tvg-name") ?: extractName(lastInf)
                val group = extractAttr(lastInf, "group-title") ?: "Ostalo"
                channels.add(ChannelItem(name, group, url))
                lastInf = null
            }
        }
    }

    private fun extractName(inf: String?): String {
        if (inf == null) return "Unknown"
        val parts = inf.split(",")
        return if (parts.size > 1) parts.last().trim() else inf
    }

    private fun extractAttr(inf: String?, key: String): String? {
        if (inf == null) return null
        val regex = Regex("""$key="([^"]+)"""")
        val m = regex.find(inf)
        return m?.groups?.get(1)?.value
    }

    override fun onDestroy() {
        super.onDestroy()
        player.release()
    }
}
