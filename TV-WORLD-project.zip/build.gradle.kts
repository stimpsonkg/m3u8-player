// Top-level Gradle file (keep minimal; open in Android Studio to finalize)
plugins {
    kotlin("jvm") version "1.8.22"
}
