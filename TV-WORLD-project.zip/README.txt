TV-WORLD Android project
-----------------------
What's inside:
- Android Studio project skeleton (Kotlin + ExoPlayer)
- Playlist at app/src/main/assets/playlist.m3u8
- GitHub Actions workflow at .github/workflows/android.yml to auto-build APK on push to main

How to use:
1) Unzip and open this folder in Android Studio.
2) Let Gradle sync (Android Studio may prompt to update configs).
3) Commit and push all files to your GitHub repo (branch main).
4) Go to Actions tab in your repo and run the "Build Android APK" workflow,
   or push a commit to trigger automatic build.
5) Download the APK from the workflow Artifacts.

Note:
- I could not produce a signed release APK here; this workflow builds a debug APK (app-debug.apk).
- If you want a signed release or auto-release to GitHub Releases, tell me and I'll add it.
