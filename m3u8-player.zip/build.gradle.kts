// Top-level build file
plugins {
    kotlin("jvm") version "1.8.22"
}
// NOTE: Open this in Android Studio -- top-level plugin configs will be handled by Android Studio.
