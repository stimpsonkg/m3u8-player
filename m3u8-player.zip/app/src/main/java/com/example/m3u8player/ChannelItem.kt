package com.example.m3u8player

data class ChannelItem(val name: String, val group: String, val url: String)
