package com.example.m3u8player

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.m3u8player.databinding.ItemChannelBinding

class ChannelAdapter(private val items: List<ChannelItem>, private val onClick: (ChannelItem)->Unit)
    : RecyclerView.Adapter<ChannelAdapter.Holder>() {

    inner class Holder(val binding: ItemChannelBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val b = ItemChannelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return Holder(b)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val it = items[position]
        holder.binding.title.text = it.name
        holder.binding.group.text = it.group
        holder.binding.root.setOnClickListener { onClick(it) }
    }

    override fun getItemCount(): Int = items.size
}
