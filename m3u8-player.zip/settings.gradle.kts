rootProject.name = "M3U8Player"
include(":app")
