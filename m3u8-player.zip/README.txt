M3U8 Player Android project
--------------------------
What I created:
- Android Studio project skeleton in Kotlin using ExoPlayer.
- Playlist placed in app/src/main/assets/playlist.m3u8
- Simple RecyclerView to list channels and PlayerView to play stream.

How to build:
1) Open this folder in Android Studio (Arctic Fox or newer).
2) Let Gradle sync; you may need to convert build files to GUI-managed Gradle (Android Studio will prompt).
3) Ensure internet permission is present (it is).
4) Build & Run on device. ExoPlayer will stream selected m3u8 links.

Notes:
- I could not compile an APK in this environment (Android SDK/tools not available).
- If you want, I can:
  * add search/filter,
  * group channels by category UI,
  * produce an APK if you provide an environment with Android SDK or use a CI service.
